function setup() {
 

  // Sets the screen to be 720 pixels wide and 400 pixels high
  createCanvas(720, 400);
  background(0);
  noSmooth();

  translate(140, 0);
   stroke(153);
  fill(80)
  rect(190,138,80,75);
  triangle(30, 85, 58, 20, 86, 85);
  //circle(x, y, r);
  ellipse(126, 116, 55, 55);



}