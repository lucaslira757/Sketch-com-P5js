function setup() {
  createCanvas(720, 400);
}
function draw() {
  background(255);
	let cor= color(290,220,0);
	fill(cor)
  strokeWeight(4);
	
		//Corpo
		ellipse(360, 199, 360, 395);
	
		//Olhos
		fill( 0 );
	  ellipse(274, 140, 70, 125);
		fill( 0 );
	  ellipse(428, 140, 70, 125);
	
		//Boca
		fill( 0 );
		arc(355,290,120,10,TWO_PI,PI) ;
push();
	
}

